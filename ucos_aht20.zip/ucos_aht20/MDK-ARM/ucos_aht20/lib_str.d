ucos_aht20\lib_str.o: ../uCOS-III/LIB/lib_str.c
ucos_aht20\lib_str.o: ../uCOS-III/LIB/lib_str.h
ucos_aht20\lib_str.o: ../uCOS-III/CPU/Port/cpu.h
ucos_aht20\lib_str.o: ../uCOS-III/CPU/cpu_def.h
ucos_aht20\lib_str.o: ../uCOS-III/CPU/Cfg/cpu_cfg.h
ucos_aht20\lib_str.o: ../uCOS-III/LIB/lib_def.h
ucos_aht20\lib_str.o: ../uCOS-III/LIB/lib_ascii.h
ucos_aht20\lib_str.o: ../uCOS-III/LIB/Cfg/lib_cfg.h
