#include "aht20.h"
#include "gpio.h"

#define AHT20_ADDR_WRITE 0x70u
#define AHT20_ADDR_READ  0x71u

static void AHT20_DelayUs(uint32_t us)
{
    volatile uint32_t n = (SystemCoreClock / 5000000u) * us;
    while (n-- != 0u) {
        __NOP();
    }
}

static void SCL(uint8_t high)
{
    HAL_GPIO_WritePin(AHT20_SCL_GPIO_Port, AHT20_SCL_Pin,
                      high ? GPIO_PIN_SET : GPIO_PIN_RESET);
    AHT20_DelayUs(3u);
}

static void SDA(uint8_t high)
{
    HAL_GPIO_WritePin(AHT20_SDA_GPIO_Port, AHT20_SDA_Pin,
                      high ? GPIO_PIN_SET : GPIO_PIN_RESET);
    AHT20_DelayUs(3u);
}

static uint8_t SDA_Read(void)
{
    return (uint8_t)HAL_GPIO_ReadPin(AHT20_SDA_GPIO_Port, AHT20_SDA_Pin);
}

static void I2C_Start(void)
{
    SDA(1u);
    SCL(1u);
    SDA(0u);
    SCL(0u);
}

static void I2C_Stop(void)
{
    SDA(0u);
    SCL(1u);
    SDA(1u);
}

static uint8_t I2C_WriteByte(uint8_t value)
{
    uint8_t i;
    uint8_t ack;

    for (i = 0u; i < 8u; i++) {
        SDA((value & 0x80u) != 0u);
        SCL(1u);
        SCL(0u);
        value <<= 1;
    }

    SDA(1u);
    SCL(1u);
    ack = (uint8_t)(SDA_Read() == 0u);
    SCL(0u);
    return ack;
}

static uint8_t I2C_ReadByte(uint8_t ack)
{
    uint8_t i;
    uint8_t value = 0u;

    SDA(1u);
    for (i = 0u; i < 8u; i++) {
        value <<= 1;
        SCL(1u);
        value |= SDA_Read();
        SCL(0u);
    }

    SDA(ack ? 0u : 1u);
    SCL(1u);
    SCL(0u);
    SDA(1u);
    return value;
}

static HAL_StatusTypeDef AHT20_WriteCommand(uint8_t command,
                                            uint8_t arg1,
                                            uint8_t arg2)
{
    uint8_t ack = 1u;
    I2C_Start();
    ack &= I2C_WriteByte(AHT20_ADDR_WRITE);
    ack &= I2C_WriteByte(command);
    ack &= I2C_WriteByte(arg1);
    ack &= I2C_WriteByte(arg2);
    I2C_Stop();
    return ack ? HAL_OK : HAL_ERROR;
}

HAL_StatusTypeDef AHT20_Init(void)
{
    uint8_t status;

    HAL_Delay(40u);
    I2C_Start();
    if (!I2C_WriteByte(AHT20_ADDR_WRITE) || !I2C_WriteByte(0x71u)) {
        I2C_Stop();
        return HAL_ERROR;
    }
    status = I2C_ReadByte(0u);
    I2C_Stop();

    if ((status & 0x08u) == 0u) {
        if (AHT20_WriteCommand(0xBEu, 0x08u, 0x00u) != HAL_OK) {
            return HAL_ERROR;
        }
        HAL_Delay(10u);
    }
    return HAL_OK;
}

HAL_StatusTypeDef AHT20_Read(float *temperature, float *humidity)
{
    uint8_t data[6];
    uint8_t i;
    uint32_t raw_humidity;
    uint32_t raw_temperature;

    if ((temperature == NULL) || (humidity == NULL)) {
        return HAL_ERROR;
    }

    if (AHT20_WriteCommand(0xACu, 0x33u, 0x00u) != HAL_OK) {
        return HAL_ERROR;
    }
    HAL_Delay(80u);

    I2C_Start();
    if (!I2C_WriteByte(AHT20_ADDR_READ)) {
        I2C_Stop();
        return HAL_ERROR;
    }
    for (i = 0u; i < sizeof(data); i++) {
        data[i] = I2C_ReadByte(i < (sizeof(data) - 1u));
    }
    I2C_Stop();
    if ((data[0] & 0x80u) != 0u) {
        return HAL_BUSY;
    }
    if ((data[0] & 0x08u) == 0u) {
        return HAL_ERROR;
    }

    raw_humidity = ((uint32_t)data[1] << 12)
                 | ((uint32_t)data[2] << 4)
                 | ((uint32_t)data[3] >> 4);
    raw_temperature = (((uint32_t)data[3] & 0x0Fu) << 16)
                    | ((uint32_t)data[4] << 8)
                    | (uint32_t)data[5];

    *humidity = (float)raw_humidity * 100.0f / 1048576.0f;
    *temperature = (float)raw_temperature * 200.0f / 1048576.0f - 50.0f;
    return HAL_OK;
}
