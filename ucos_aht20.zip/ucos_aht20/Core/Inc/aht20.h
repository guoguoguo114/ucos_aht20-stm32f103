#ifndef AHT20_H
#define AHT20_H

#include "main.h"

HAL_StatusTypeDef AHT20_Init(void);
HAL_StatusTypeDef AHT20_Read(float *temperature, float *humidity);

#endif
