ucos_aht20\lib_math.o: ../uCOS-III/LIB/lib_math.c
ucos_aht20\lib_math.o: ../uCOS-III/LIB/lib_math.h
ucos_aht20\lib_math.o: ../uCOS-III/CPU/Port/cpu.h
ucos_aht20\lib_math.o: ../uCOS-III/CPU/cpu_def.h
ucos_aht20\lib_math.o: ../uCOS-III/CPU/Cfg/cpu_cfg.h
ucos_aht20\lib_math.o: ../uCOS-III/CPU/cpu_core.h
ucos_aht20\lib_math.o: ../uCOS-III/LIB/lib_def.h
