ucos_aht20\cpu_a.o: ../uCOS-III/CPU/Port/cpu_a.asm
