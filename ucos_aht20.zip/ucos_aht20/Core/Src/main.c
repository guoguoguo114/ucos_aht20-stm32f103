/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "aht20.h"
#include "os.h"
#include <stdio.h>
#include <string.h>

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

#define APP_TASK_STK_SIZE 256u
static OS_TCB task1_tcb, task2_tcb, task3_tcb;
static CPU_STK task1_stk[APP_TASK_STK_SIZE];
static CPU_STK task2_stk[APP_TASK_STK_SIZE];
static CPU_STK task3_stk[APP_TASK_STK_SIZE];
static OS_MUTEX uart_mutex;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
static void AppTask1(void *p_arg);
static void AppTask2(void *p_arg);
static void AppTask3(void *p_arg);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

static void AppTask1(void *p_arg)
{
  OS_ERR err;
  (void)p_arg;
  OS_CPU_SysTickInitFreq(SystemCoreClock);
  while (1) {
    HAL_GPIO_TogglePin(LED_GPIO_Port, LED_Pin);
    OSTimeDlyHMSM(0, 0, 1, 0, OS_OPT_TIME_DLY, &err);
  }
}

static void AppTask2(void *p_arg)
{
  OS_ERR err;
  const char msg[] = "Task2 alive\r\n";
  (void)p_arg;
  while (1) {
    HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_8);
    OSMutexPend(&uart_mutex, 0, OS_OPT_PEND_BLOCKING, 0, &err);
    HAL_UART_Transmit(&huart1, (uint8_t *)msg, sizeof(msg) - 1u, HAL_MAX_DELAY);
    OSMutexPost(&uart_mutex, OS_OPT_POST_NONE, &err);
    OSTimeDlyHMSM(0, 0, 3, 0, OS_OPT_TIME_DLY, &err);
  }
}

static void AppTask3(void *p_arg)
{
  OS_ERR err;
  float temperature;
  float humidity;
  char msg[80];
  int t100;
  unsigned int h100;
  (void)p_arg;
  if (AHT20_Init() != HAL_OK) {
    const char fail[] = "AHT20 init failed: check wiring/pull-ups\r\n";
    OSMutexPend(&uart_mutex, 0, OS_OPT_PEND_BLOCKING, 0, &err);
    HAL_UART_Transmit(&huart1, (uint8_t *)fail, sizeof(fail) - 1u, HAL_MAX_DELAY);
    OSMutexPost(&uart_mutex, OS_OPT_POST_NONE, &err);
  }
  while (1) {
    if (AHT20_Read(&temperature, &humidity) == HAL_OK) {
      t100 = (int)(temperature * 100.0f + (temperature >= 0.0f ? 0.5f : -0.5f));
      h100 = (unsigned int)(humidity * 100.0f + 0.5f);
      (void)snprintf(msg, sizeof(msg), "AHT20: T=%d.%02d C, RH=%u.%02u%%\r\n",
                     t100 / 100, (t100 < 0 ? -t100 : t100) % 100,
                     h100 / 100u, h100 % 100u);
    } else {
      (void)snprintf(msg, sizeof(msg), "AHT20 read failed (status=%d)\r\n",
                     (int)HAL_ERROR);
    }
    OSMutexPend(&uart_mutex, 0, OS_OPT_PEND_BLOCKING, 0, &err);
    HAL_UART_Transmit(&huart1, (uint8_t *)msg, (uint16_t)strlen(msg), HAL_MAX_DELAY);
    OSMutexPost(&uart_mutex, OS_OPT_POST_NONE, &err);
    OSTimeDlyHMSM(0, 0, 2, 0, OS_OPT_TIME_DLY, &err);
  }
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART1_UART_Init();
  /* USER CODE BEGIN 2 */

  OS_ERR err;
  OSInit(&err);
  OSMutexCreate(&uart_mutex, "UART Mutex", &err);
  OSTaskCreate(&task1_tcb, "Task1", AppTask1, 0, 5,
               task1_stk, APP_TASK_STK_SIZE / 10u, APP_TASK_STK_SIZE,
               0, 0, 0, OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR, &err);
  OSTaskCreate(&task2_tcb, "Task2", AppTask2, 0, 6,
               task2_stk, APP_TASK_STK_SIZE / 10u, APP_TASK_STK_SIZE,
               0, 0, 0, OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR, &err);
  OSTaskCreate(&task3_tcb, "Task3", AppTask3, 0, 7,
               task3_stk, APP_TASK_STK_SIZE / 10u, APP_TASK_STK_SIZE,
               0, 0, 0, OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR, &err);
  OSStart(&err);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* OSStart() does not return. */
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
