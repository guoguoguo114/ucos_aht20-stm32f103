ucos_aht20\os_cpu_a.o: ../uCOS-III/Port/os_cpu_a.asm
