ucos_aht20\cpu_c.o: ../uCOS-III/CPU/Port/cpu_c.c
ucos_aht20\cpu_c.o: ../uCOS-III/CPU/Port/cpu.h
ucos_aht20\cpu_c.o: ../uCOS-III/CPU/cpu_def.h
ucos_aht20\cpu_c.o: ../uCOS-III/CPU/Cfg/cpu_cfg.h
ucos_aht20\cpu_c.o: ../uCOS-III/CPU/cpu_core.h
ucos_aht20\cpu_c.o: ../uCOS-III/LIB/lib_def.h
